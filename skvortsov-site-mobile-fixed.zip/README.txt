Юрій Скворцов — Procurement Advisory

Файли index.html і office.jpg потрібно розмістити в корені одного Cloudflare Pages проєкту.

Cloudflare Pages: Workers & Pages → Create → Pages → Upload assets → завантажити ZIP.
Якщо використовується Cloudflare Worker із кодом, ZIP для Pages не оновлює Worker автоматично.

Після публікації перевірте меню, кнопки tel:, mailto: та Viber на телефоні.
CV PDF і LinkedIn не додані без підтверджених файлу/посилання.
